import streamlit as st

# Mock data for demonstration purposes
result = st.session_state.get('result', {
    'annotated_image_path': 'assets/annotated_image.png',
    'text_lines': ["This is a sample text line 1", "This is a sample text line 2"],
    'translated_lines': ["Ceci est une ligne de texte d'exemple 1", "Ceci est une ligne de texte d'exemple 2"]
})

st.set_page_config(page_title="OCR Results", page_icon=":memo:", layout="centered")

# Custom CSS for styling
st.markdown("""
    <style>
    .main {
        background-color: green;
    }
    .title {
        text-align: center;
        color: #333;
    }
    .card {
        padding: 20px;
        border-radius: 10px;
        background-color: #fff;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .image-container {
        text-align: center;
        margin-bottom: 20px;
    }
    .results-container {
        margin-top: 20px;
    }
    .list-group {
        list-style: none;
        padding: 0;
    }
    .list-group-item {
        background-color: #f1f1f1;
        margin-bottom: 5px;
        padding: 10px;
        border-radius: 5px;
    }
    </style>
""", unsafe_allow_html=True)

st.markdown("<h1 class='title'>OCR Results</h1>", unsafe_allow_html=True)

st.markdown("<div class='card'>", unsafe_allow_html=True)

st.markdown("<div class='image-container'>", unsafe_allow_html=True)
st.image(result['annotated_image_path'], caption='Annotated Image', use_column_width=True)
st.markdown("</div>", unsafe_allow_html=True)

st.markdown("<div class='results-container'>", unsafe_allow_html=True)

st.markdown("### Original Text:")
for line in result['text_lines']:
    st.markdown(f"<div class='list-group-item'>{line}</div>", unsafe_allow_html=True)

st.markdown("### Translated Text:")
for line in result['translated_lines']:
    st.markdown(f"<div class='list-group-item'>{line}</div>", unsafe_allow_html=True)

st.markdown("</div>", unsafe_allow_html=True)

if st.button("Upload Another Image"):
    # Redirect to home page
    st.experimental_set_query_params(page="home")

st.markdown("</div>", unsafe_allow_html=True)

# Include a footer
st.markdown("""
    <hr>
    <footer>
        <p style='text-align: center;'>Developed by [Your Name]</p>
    </footer>
""", unsafe_allow_html=True)
