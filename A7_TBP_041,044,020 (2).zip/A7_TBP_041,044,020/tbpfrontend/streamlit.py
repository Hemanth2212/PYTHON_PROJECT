import streamlit as st
import requests

st.markdown(
    """
    <style>
    .stApp {
        background-color: black;
        color: white;
    }
    .stApp h1, .stApp h2, .stApp h3, .stApp h4, .stApp h5, .stApp h6, .stApp div, .stApp span, .stApp label {
        color: white;
    }
    .stFileUploader label div {
        background-color: rgba(255, 255, 255, 0.1) !important;
        color: black;
        border: 1px solid white !important;
    }
    .stFileUploader:hover label div {
        background-color: rgba(255, 255, 255, 0.2) !important;
        color: black;
    }
    .stFileUploader label div span {
        color:black
    }
    </style>
    """,
    unsafe_allow_html=True
)
# Streamlit page layout and interaction
st.title('Image Text Translation')

uploaded_file = st.file_uploader("Upload an image...", type=["jpg", "png"])

if uploaded_file is not None:
    files = {'file': uploaded_file}
    url = 'http://localhost:5000/'
    response = requests.post(url, files=files)

    if response.status_code == 200:
        data = response.json()

        st.subheader('Original Image with OCR Annotations')
        st.image(data['annotated_image'])

        st.subheader('Translated Text')
        for line in data['translated_lines']:
            st.write(line)
    else:
        st.error(f"Error: {response.text}")
