import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Embedding, LSTM, Dense
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
import numpy as np

# Function to load dataset from text file
def load_dataset(file_path):
    telugu_sentences = []
    eng_sentences = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            parts = line.strip().split('    ')  # Split by four spaces
            if len(parts) == 2:  # Ensure two parts are present
                telugu_sentence, eng_sentence = parts
                telugu_sentences.append(telugu_sentence)
                eng_sentences.append(eng_sentence)
            else:
                print(f"Skipping line: {line.strip()}")  # Log problematic lines
    return telugu_sentences, eng_sentences

# Load dataset (replace with your actual file path)
data_path = 'data/eng1.txt'  # Update with your actual file path
telugu_sentences, eng_sentences = load_dataset(data_path)

# Tokenize and prepare data
tokenizer_telugu = Tokenizer(oov_token='<unk>')
tokenizer_telugu.fit_on_texts(telugu_sentences)
telugu_seq = tokenizer_telugu.texts_to_sequences(telugu_sentences)
telugu_seq = pad_sequences(telugu_seq, padding='post')

tokenizer_eng = Tokenizer(oov_token='<unk>')
tokenizer_eng.fit_on_texts(eng_sentences)
eng_seq = tokenizer_eng.texts_to_sequences(eng_sentences)
eng_seq = pad_sequences(eng_seq, padding='post')

# Define model architecture
vocab_size_telugu = len(tokenizer_telugu.word_index) + 1
vocab_size_eng = len(tokenizer_eng.word_index) + 1
embedding_dim = 256
hidden_dim = 512

# Encoder
encoder_inputs = Input(shape=(None,), name='encoder_inputs')
encoder_embedding = Embedding(vocab_size_telugu, embedding_dim, name='encoder_embedding')(encoder_inputs)
encoder_lstm, state_h, state_c = LSTM(hidden_dim, return_state=True, name='encoder_lstm')(encoder_embedding)
encoder_states = [state_h, state_c]

# Decoder
decoder_inputs = Input(shape=(None,), name='decoder_inputs')
decoder_embedding = Embedding(vocab_size_eng, embedding_dim, name='decoder_embedding')(decoder_inputs)
decoder_lstm = LSTM(hidden_dim, return_sequences=True, return_state=True, name='decoder_lstm')
decoder_outputs, _, _ = decoder_lstm(decoder_embedding, initial_state=encoder_states)
decoder_dense = Dense(vocab_size_eng, activation='softmax', name='decoder_dense')
decoder_outputs = decoder_dense(decoder_outputs)

# Define the model
model = Model([encoder_inputs, decoder_inputs], decoder_outputs)

# Compile the model
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy')

# Prepare the data for training
input_telugu = np.array(telugu_seq)
input_eng = np.array(eng_seq[:, :-1])  # shifted target sequences
output_eng = np.expand_dims(eng_seq[:, 1:], -1)  # shifted target sequences

# Train the model
model.fit([input_telugu, input_eng], output_eng, epochs=1, batch_size=1)

# Define the encoder model for inference
encoder_model = Model(encoder_inputs, encoder_states)

# Define the decoder model for inference
decoder_state_input_h = Input(shape=(hidden_dim,), name='decoder_state_input_h')
decoder_state_input_c = Input(shape=(hidden_dim,), name='decoder_state_input_c')
decoder_states_inputs = [decoder_state_input_h, decoder_state_input_c]

decoder_embedding_infer = decoder_embedding(decoder_inputs)
decoder_lstm_infer, state_h_infer, state_c_infer = decoder_lstm(
    decoder_embedding_infer, initial_state=decoder_states_inputs
)
decoder_states_infer = [state_h_infer, state_c_infer]
decoder_outputs_infer = decoder_dense(decoder_lstm_infer)
decoder_model = Model(
    [decoder_inputs] + decoder_states_inputs,
    [decoder_outputs_infer] + decoder_states_infer
)

# Inference (translation)
def translate_sentence(sentence):
    seq = tokenizer_telugu.texts_to_sequences([sentence])
    padded_seq = pad_sequences(seq, padding='post')
    
    # Encode the input as state vectors
    states_value = encoder_model.predict(padded_seq)
    
    # Generate empty target sequence of length 1
    target_seq = np.zeros((1, 1))
    target_seq[0, 0] = tokenizer_eng.word_index.get('<sos>', 0)  # <sos> token index
    
    # Sampling loop for a batch of sequences
    translated_sentence = []
    while True:
        output_tokens, h, c = decoder_model.predict([target_seq] + states_value)
        
        # Sample a token
        sampled_token_index = np.argmax(output_tokens[0, -1, :])
        sampled_word = tokenizer_eng.index_word.get(sampled_token_index, '<unk>')
        translated_sentence.append(sampled_word)
        
        # Exit condition: either hit max length or find stop token
        if sampled_word == '<eos>' or len(translated_sentence) > 50:
            break
        
        # Update the target sequence (length 1)
        target_seq = np.zeros((1, 1))
        target_seq[0, 0] = sampled_token_index
        
        # Update states
        states_value = [h, c]
    
    return ' '.join(translated_sentence)

# Example translation
input_sentence = "అతను నిన్న ఒక లేఖ రాశాడు."
translated_sentence = translate_sentence(input_sentence)
print(f'Input: {input_sentence}')
print(f'Translated: {translated_sentence}')
