# app.py
from flask import Flask, render_template, request, redirect, url_for ,jsonify
import os
from PIL import Image, ImageDraw
import cv2
import numpy as np
import easyocr
from googletrans import Translator

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['STATIC_FOLDER'] = 'static/uploads'

translator = Translator()

# Ensure the upload directories exist
def ensure_directories_exist():
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])
    if not os.path.exists(app.config['STATIC_FOLDER']):
        os.makedirs(app.config['STATIC_FOLDER'])

# Initialize EasyOCR reader for Telugu
reader = easyocr.Reader(['te'])

# Function to process uploaded image
def process_image(image_path):
    im = Image.open(image_path)
    img = cv2.cvtColor(np.array(im), cv2.COLOR_RGB2BGR)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.convertScaleAbs(gray, alpha=2, beta=0)
    gray = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
    gray = cv2.bilateralFilter(gray, 9, 75, 75)
    kernel = np.ones((1, 1), np.uint8)
    gray = cv2.dilate(gray, kernel, iterations=1)
    gray = cv2.erode(gray, kernel, iterations=1)

    bounds = reader.readtext(gray)
    gray_pil = Image.fromarray(gray)
    gray_with_boxes = draw_boxes(gray_pil, bounds)

    bounds.sort(key=lambda x: x[0][0][1])
    text_lines = []
    current_line = []
    line_spacing_threshold = 20

    for bound in bounds:
        text = bound[1]
        box = bound[0]
        y = box[0][1]

        if not current_line:
            current_line.append(bound)
        else:
            last_box = current_line[-1][0]
            last_y = last_box[0][1]

            if abs(y - last_y) < line_spacing_threshold:
                current_line.append(bound)
            else:
                current_line.sort(key=lambda b: b[0][0][0])
                line_text = ' '.join([b[1] for b in current_line])
                text_lines.append(line_text)
                current_line = [bound]

    if current_line:
        current_line.sort(key=lambda b: b[0][0][0])
        line_text = ' '.join([b[1] for b in current_line])
        text_lines.append(line_text)

    return text_lines, gray_with_boxes

# Function to draw bounding boxes
def draw_boxes(image, bounds, color='yellow', width=2):
    draw = ImageDraw.Draw(image)
    for bound in bounds:
        p0, p1, p2, p3 = bound[0]
        draw.line([*p0, *p1, *p2, *p3, *p0], fill=color, width=width)
    return image

# Route for the home page
@app.route('/', methods=['POST'])
def home():
    ensure_directories_exist()

    if 'file' not in request.files:
        return jsonify({'error': 'No file part'})

    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'})

    file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(file_path)

    text_lines, annotated_image = process_image(file_path)

    annotated_image_path = os.path.join(app.config['STATIC_FOLDER'], file.filename)
    annotated_image.save(annotated_image_path)

    translated_lines = []
    for line in text_lines:
        translated_text = translator.translate(line, src='te', dest='en').text
        translated_lines.append(translated_text)

    return jsonify({'annotated_image': annotated_image_path, 'translated_lines': translated_lines})

if __name__ == '__main__':
    app.run(debug=True)
