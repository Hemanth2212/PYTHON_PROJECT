from googletrans import Translator

def translate_text(text, src_lang='te', target_lang='en'):
    translator = Translator()
    
    # Translate text
    translated = translator.translate(text, src=src_lang, dest=target_lang)
    
    return translated.text

# Example usage
text_to_translate = "నా పేరు రేవంత్ పట్లూరి"
source_language = "te"  # Telugu
target_language = "en"  # English
translated_text = translate_text(text_to_translate, source_language, target_language)
print(f"Translated text: {translated_text}")



